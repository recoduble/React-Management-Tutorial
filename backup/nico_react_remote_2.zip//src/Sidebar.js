import React, { useState } from "react";
import "./Sidebar.css"; // CSS는 아래 참고

function Sidebar() {
  const [expanded, setExpanded] = useState(true);

  return (
    <div className={`sidebar ${expanded ? "expanded" : "collapsed"}`}>
      <button onClick={() => setExpanded(!expanded)}>
        {expanded ? "축소" : "확대"}
      </button>
      <nav>
        <ul>
          <li>메뉴1</li>
          <li>메뉴2</li>
          <li>메뉴3</li>
        </ul>
      </nav>
    </div>
  );
}

export default Sidebar;

import React, { useState, useEffect, useRef } from "react";
import ReactDOM from "react-dom/client"; // ✅ React 18용 import 경로
import Sidebar from "./Sidebar.js";
import useAxios from "./useAxios";

// const App = () => {
//   const { loading, data, error, refetch } = useAxios({
//     url: "https://yts.mx/api/v2/list_movies.json",
//   });
//   console.log(
//     `Loading : ${loading} \nError:${error} \nData:${JSON.stringify(data)} `
//   );
//   return (
//     <div className="App">
//       <div>
//         <h1>{data && data.status}</h1>
//         <h2>{loading && "Loading"}</h2>
//         <button onClick={refetch}>refetch</button>
//       </div>
//     </div>
//   );
// };

const App = () => {
  return <Sidebar />;
};

const rootElement = document.getElementById("root");
const root = ReactDOM.createRoot(rootElement); // ✅ createRoot 사용
root.render(<App />);
